package com.ahxbapp.jsqb.updateapp;

/**
 * Created by sanmu on 2016/10/13 0013.
 */
public interface Callback {
    public void callback();
}
