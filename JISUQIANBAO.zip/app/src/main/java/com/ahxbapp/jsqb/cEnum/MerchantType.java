package com.ahxbapp.jsqb.cEnum;

public enum  MerchantType{
    MerchantType_XiuLi,
    MerchantType_BaoYang,
    MerchantType_JiuYuan,
}