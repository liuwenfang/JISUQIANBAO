package com.ahxbapp.jsqb.model;

/**
 * Created by zzx on 2017/12/20 0020.
 */

public class WxModel {

    /**
     * ID : 8
     * wxCode : 18788899978
     */

    private int ID;
    private String wxCode;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getWxCode() {
        return wxCode;
    }

    public void setWxCode(String wxCode) {
        this.wxCode = wxCode;
    }
}
