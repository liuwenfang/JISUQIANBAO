package com.ahxbapp.jsqb.wxapi;

//import com.umeng.socialize.weixin.view.WXCallbackActivity;

import android.app.Activity;

/**
 * Created by Admin on 2016/11/4.
 * Page
 */
public class WXEntryActivity extends Activity{
//    WXCallbackActivity
}
