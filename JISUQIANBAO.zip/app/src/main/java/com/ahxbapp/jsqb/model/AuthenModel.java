package com.ahxbapp.jsqb.model;

/**
 * Created by Jayzhang on 16/10/17.
 */
public class AuthenModel {


    /**
     * IsBank : 0
     * IsContact : 0
     * IsID : 1
     * IsID2 : 0
     * IsLNet : 0
     * IsMobile : 0
     * IsPay : 1
     * IsPerson : 0
     * IsTabao : 0
     * IsZM : 0
     * Status : 1
     * isId_dbr : 0
     * isMobile_dbr : 0
     */

    private int IsBank;
    private int IsContact;
    private int IsID;
    private int IsID2;
    private int IsLNet;
    private int IsMobile;
    private int IsPay;
    private int IsPerson;
    private int IsTabao;
    private int IsZM;
    private int Status;
    private int isId_dbr;
    private int isMobile_dbr;

    public int getIsBank() {
        return IsBank;
    }

    public void setIsBank(int IsBank) {
        this.IsBank = IsBank;
    }

    public int getIsContact() {
        return IsContact;
    }

    public void setIsContact(int IsContact) {
        this.IsContact = IsContact;
    }

    public int getIsID() {
        return IsID;
    }

    public void setIsID(int IsID) {
        this.IsID = IsID;
    }

    public int getIsID2() {
        return IsID2;
    }

    public void setIsID2(int IsID2) {
        this.IsID2 = IsID2;
    }

    public int getIsLNet() {
        return IsLNet;
    }

    public void setIsLNet(int IsLNet) {
        this.IsLNet = IsLNet;
    }

    public int getIsMobile() {
        return IsMobile;
    }

    public void setIsMobile(int IsMobile) {
        this.IsMobile = IsMobile;
    }

    public int getIsPay() {
        return IsPay;
    }

    public void setIsPay(int IsPay) {
        this.IsPay = IsPay;
    }

    public int getIsPerson() {
        return IsPerson;
    }

    public void setIsPerson(int IsPerson) {
        this.IsPerson = IsPerson;
    }

    public int getIsTabao() {
        return IsTabao;
    }

    public void setIsTabao(int IsTabao) {
        this.IsTabao = IsTabao;
    }

    public int getIsZM() {
        return IsZM;
    }

    public void setIsZM(int IsZM) {
        this.IsZM = IsZM;
    }

    public int getStatus() {
        return Status;
    }

    public void setStatus(int Status) {
        this.Status = Status;
    }

    public int getIsId_dbr() {
        return isId_dbr;
    }

    public void setIsId_dbr(int isId_dbr) {
        this.isId_dbr = isId_dbr;
    }

    public int getIsMobile_dbr() {
        return isMobile_dbr;
    }

    public void setIsMobile_dbr(int isMobile_dbr) {
        this.isMobile_dbr = isMobile_dbr;
    }
}
