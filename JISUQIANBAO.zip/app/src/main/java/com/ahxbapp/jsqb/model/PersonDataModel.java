package com.ahxbapp.jsqb.model;

/**
 * Created by Jayzhang on 16/10/20.
 */
public class PersonDataModel {
    String Mobile, PosName, IncName, RelaName, RelaMobile, SocName, SocMobile, Identity, TrueName, BankName, CardNo;

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String mobile) {
        Mobile = mobile;
    }

    public String getPosName() {
        return PosName;
    }

    public void setPosName(String posName) {
        PosName = posName;
    }

    public String getIncName() {
        return IncName;
    }

    public void setIncName(String incName) {
        IncName = incName;
    }

    public String getRelaName() {
        return RelaName;
    }

    public void setRelaName(String relaName) {
        RelaName = relaName;
    }

    public String getRelaMobile() {
        return RelaMobile;
    }

    public void setRelaMobile(String relaMobile) {
        RelaMobile = relaMobile;
    }

    public String getSocName() {
        return SocName;
    }

    public void setSocName(String socName) {
        SocName = socName;
    }

    public String getSocMobile() {
        return SocMobile;
    }

    public void setSocMobile(String socMobile) {
        SocMobile = socMobile;
    }

    public String getIdentity() {
        return Identity;
    }

    public void setIdentity(String identity) {
        Identity = identity;
    }

    public String getTrueName() {
        return TrueName;
    }

    public void setTrueName(String trueName) {
        TrueName = trueName;
    }

    public String getBankName() {
        return BankName;
    }

    public void setBankName(String bankName) {
        BankName = bankName;
    }

    public String getCardNo() {
        return CardNo;
    }

    public void setCardNo(String cardNo) {
        CardNo = cardNo;
    }
}
