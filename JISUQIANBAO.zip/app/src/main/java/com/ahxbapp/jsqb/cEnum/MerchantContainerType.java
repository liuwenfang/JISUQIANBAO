package com.ahxbapp.jsqb.cEnum;

public enum MerchantContainerType {
    MerchantContainerType_Home,
    MerchantContainerType_JiuYuan,
}