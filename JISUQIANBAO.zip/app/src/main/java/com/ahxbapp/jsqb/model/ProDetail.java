package com.ahxbapp.jsqb.model;

/**
 * Created by gravel on 16/9/6.
 */
public class ProDetail {
    private int colorId;
    private String picture,colour;

    public int getColorId() {
        return colorId;
    }

    public void setColorId(int colorId) {
        this.colorId = colorId;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }
}
