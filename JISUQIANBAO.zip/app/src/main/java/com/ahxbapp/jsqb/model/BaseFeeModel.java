package com.ahxbapp.jsqb.model;

/**
 * Created by Jayzhang on 16/10/24.
 */
public class BaseFeeModel {
    public String getApplyfee() {
        return Applyfee;
    }

    public void setApplyfee(String applyfee) {
        Applyfee = applyfee;
    }

    public String getUserfee() {
        return Userfee;
    }

    public void setUserfee(String userfee) {
        Userfee = userfee;
    }

    String Applyfee,Userfee;

}
