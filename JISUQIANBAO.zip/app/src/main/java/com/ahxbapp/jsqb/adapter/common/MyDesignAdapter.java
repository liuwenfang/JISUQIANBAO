package com.ahxbapp.jsqb.adapter.common;

import android.content.Context;

import java.util.List;

/**
 * Created by xp on 16/8/27.
 */
public class MyDesignAdapter extends CommonAdapter {
    public MyDesignAdapter(Context context, List datas, int layoutId) {
        super(context, datas, layoutId);
    }

    @Override
    public void convert(ViewHolder holder, Object o) {

    }
}
