package com.ahxbapp.jsqb.model;

/**
 * Created by Jayzhang on 16/9/9.
 */
public class DestroyModel {
}
