package com.ahxbapp.jsqb.adapter;

/**
 * Created by Jayzhang on 16/10/20.
 */
public class FAQAdapter {


}
