package com.ahxbapp.jsqb.model;

/**
 * Created by Jayzhang on 16/10/20.
 */
public class FAQModel {
    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getContents() {
        return Contents;
    }

    public void setContents(String contents) {
        Contents = contents;
    }

    String Title,Contents;
}
