package com.ahxbapp.jsqb.activity;

import android.os.Bundle;

import com.ahxbapp.common.ui.BaseActivity;
import com.ahxbapp.jsqb.R;
/**
 * 手机号认证  3
 */
public class Phone3Activity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone3);
    }
}
