package com.ahxbapp.jsqb.event;

import com.ahxbapp.jsqb.model.ContactsInfo;

/**
 * Created by xp on 16/9/10.
 */
public interface UserEvent {
    public  class  loginDestoryEvent{

    }

    public class settingDestoryEvent{

    }

    public class forgetDestoryEvent{

    }

    public class CashOrderEvent{

    }

    public class changeStatus{

    }
}
