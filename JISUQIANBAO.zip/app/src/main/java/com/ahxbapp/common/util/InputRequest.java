package com.ahxbapp.common.util;

/**
 * Created by chenchao on 15/12/22.
 */
public interface InputRequest {

    public boolean isCurrectFormat(String s);
}
