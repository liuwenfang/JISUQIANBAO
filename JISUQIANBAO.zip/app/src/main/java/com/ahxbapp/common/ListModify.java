package com.ahxbapp.common;

/**
 * Created by gravel on 14-9-26.
 */
public final class ListModify {
    public static final int RESULT_EDIT_LIST = 11;

    public static final String TYPE = "TYPE";
    public static final int Add = 1;

    public static final int Edit = 2;
    public static final int Delete = 3;

    public static final String ID = "ID";
    public static final String DATA = "DATA";

}
