package com.ahxbapp.common.htmltext;


/**
 * Created by chenchao on 15/3/9.
 */
public class LinkCreate {



}
