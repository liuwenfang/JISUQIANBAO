package com.ahxbapp.common;

/**
 * Created by lqfang on 2017/3/30.
 */

public class Constant {

    // 短信验证码 http://mob.com/
//    public static final String MOBSMS_APPKEY = "98edf380719c";
//    public static final String MOBSMS_APPSECRET = "b6f7394c324ce45f882e6f663615e0c8";

    public static final String UM_APPKEY = "58ddec814544cb45fd000f61";

    // 微信开发平台 https://open.weixin.qq.com
    public static final String WEIXIN_APPID = "wx4958aa2f6ea421db";
    public static final String WEIXIN_APPSECRET = "ad127ba8e2e0b5640e38bacd7c2d38ff";

    // QQ http://connect.qq.com
    public static final String QQ_APPID = "1105718739";
    public static final String QQ_APPKEY = "rN3NABluXoJSBTA6";

    // 微博
    public static final String SINA_APPID = "1105718739";
    public static final String SINA_APPKEY = "rN3NABluXoJSBTA6";
}
