package com.ahxbapp.common.inter;

import com.ahxbapp.common.ui.BaseWebFragment;

/**
 * Created by Administrator on 2018/6/27.
 */

public interface BackHandledInterface {
    void setSelectedFragment(BaseWebFragment selectedFragment);
}
