package com.ahxbapp.common.widget;

/**
 * Created by chenchao on 15/5/11.
 * Application里面调用 initValue() 初始化
 */
public class Dimens {

    public static float PROJECT_ICON_ROUND = 2;

}
